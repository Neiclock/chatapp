<?php
// Database connection parameters
$host = 'localhost';
$username = 'user';
$password = 'password'; 
$db_name = 'chat_db'; 

// Create a MySQLi database connection
$connection = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($connection->connect_error) {
    // Log the error instead of displaying it
    error_log("Connection failed: " . $connection->connect_error);
    die("Connection failed. Please contact the administrator.");
}

return $connection;
?>
